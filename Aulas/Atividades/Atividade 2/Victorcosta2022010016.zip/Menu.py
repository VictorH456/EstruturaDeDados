#Função Menu: Ela serve para mostrar as opções no inicio do game.
def Menu():
    print("""\n### JOGO DA FORCA ###
[1] Play!
[2] Ranking
[3] Sair""")